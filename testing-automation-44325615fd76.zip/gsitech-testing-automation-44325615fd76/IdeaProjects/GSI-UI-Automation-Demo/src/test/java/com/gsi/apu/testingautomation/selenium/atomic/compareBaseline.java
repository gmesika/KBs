package com.gsi.apu.testingautomation.selenium.atomic;

import com.gsi.apu.testingautomation.selenium.Infra.SeleniumWrappers;
import lombok.extern.slf4j.Slf4j;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

@Slf4j
public class compareBaseline extends SeleniumWrappers {

    public Map<String, Map<String, String>> getResultsAsMap(String idClassName, String resultClassName) {

        Map<String, Map<String, String>> resultsMap = new HashMap<>();
        List<WebElement> resultsList = getListOfElements(resultClassName);
//        log.info("resultsList size = " + resultsList.size());
        List<WebElement> idList = getListOfElements(idClassName);
//        log.info("idList size = " + idList.size());
        List<String> idListAsStrings = new ArrayList<>();
        for (int i = 0; i < idList.size(); i++) {
            idListAsStrings.add(i, idList.get(i).getText());
        }
        int iterationStopNum = (resultsList.size()/idListAsStrings.size());
        int j = 0;
        for (int i = 0; i < resultsList.size(); i +=2) {
            if (i % iterationStopNum == 0 && i != 0) {j ++; }
            String mainId = idListAsStrings.get(j);
            if (resultsMap.containsKey(mainId)) {
                resultsMap.get(mainId).put(resultsList.get(i).getAttribute("innerText"), resultsList.get(i+1).getAttribute("innerText"));
            }
            else {
                Map<String, String> resultsPair = new HashMap<>();
                resultsPair.put(resultsList.get(i).getAttribute("innerText"), resultsList.get(i+1).getAttribute("innerText"));
                resultsMap.put(mainId, resultsPair);
            }
        }
        return resultsMap;
    }

    public Map<String, Map<String, String>> getFacesResultsAsMap() {

        Map<String, Map<String, String>> resultsMap = new HashMap<>();
        List<WebElement> resultsList = getListOfElements("facesResultName");
//        log.info("resultsList size = " + resultsList.size());
        List<WebElement> imgList = getDriver().findElements(By.xpath("//div[@class='fr-result-item']/img"));
//        log.info("imgList size = " + imgList.size());
        List<WebElement> idList = getListOfElements("facesIdName");
//        log.info("idList size = " + idList.size());
        List<String> idListAsStrings = new ArrayList<>();
        for (int i = 0; i < idList.size(); i++) {
            idListAsStrings.add(i, idList.get(i).getAttribute("src"));
        }

        int iterationStopNum = (resultsList.size()/idListAsStrings.size());
        int j = 0;
        for (int i = 0; i < resultsList.size(); i++) {
            if (i % iterationStopNum == 0 && i != 0) {j++; }
            String mainId = idListAsStrings.get(j);
            if (resultsMap.containsKey(mainId)) {
                resultsMap.get(mainId).put(imgList.get(i).getAttribute("src"), resultsList.get(i).getAttribute("innerText").replace("Name\n" + "Score", "").trim());
            }
            else {
                Map<String, String> resultsPair = new HashMap<>();
                resultsPair.put(imgList.get(i).getAttribute("src"), resultsList.get(i).getAttribute("innerText").replace("Name\n" + "Score", "").trim());
                resultsMap.put(mainId, resultsPair);
            }
        }
//        log.info("results map size: " + resultsMap.values().size());
        return resultsMap;
    }
    // TODO change method to create JSONObject for other baselines
    public void createJsonBaseline(String fileName, String idClassName, String resultClassName) {
        String jsonPath = "/home/rpugatsch/projects/testing-automation/IdeaProjects/GSI-UI-Automation-Demo/src/test/resources/" + fileName;
        try {
            FileWriter fileWriter = new FileWriter(jsonPath);
            // TODO change method to create JSONObject for other baselines
            JSONObject jsonResults = new JSONObject(getFacesResultsAsMap());
//            jsonResults.writeJSONString(fileWriter);
            fileWriter.write(jsonResults.toString());
            fileWriter.close();
//            am.quitDriver();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Map<String, Map<String, String>> getBaselineFromJson(String jsonPath){

        JSONParser jsonParser = new JSONParser();
        try {
            FileReader reader = new FileReader(jsonPath);
            //Read JSON file
            Object obj = jsonParser.parse(reader);

            JSONObject jsonBaseline = (JSONObject) obj;
            Map<String, Map<String, String>> baselineMap;
            baselineMap = (Map<String, Map<String, String>>) jsonBaseline;
//            System.out.println(baselineMap);
            return baselineMap;
        }
        catch (FileNotFoundException | ParseException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void compareResultsToJsonBaseLine(Map<String, Map<String, String>> testMap, String baselineName) {
        String jsonPath = "/home/rpugatsch/projects/testing-automation/IdeaProjects/GSI-UI-Automation-Demo/src/test/resources/";
        Map<String, Map<String, String>> baseline = new HashMap<>();
        switch (baselineName) {
            case "molecule38Mil":
                baseline = getBaselineFromJson(jsonPath + "molecule38MilBaseline.json");
                break;
            case "visualParis":
                baseline = getBaselineFromJson(jsonPath + "visualParisBaseline.json");
                break;
            case "facesBaseline":
                baseline = getBaselineFromJson(jsonPath + "facesBaseline.json");
        }
        String key = "";
        int i = 0;
        Iterator<String> keyIterator = testMap.keySet().iterator();
        while (keyIterator.hasNext()) {
//            log.info("iteration number: "+ ++i);
            key = keyIterator.next();
            Assert.assertTrue("testFailed", baseline.get(key).entrySet().containsAll(testMap.get(key).entrySet()));
        }
    }

    public static void main(String[] args) {
        compareBaseline gr = new compareBaseline();
        atomicMethods am = new atomicMethods();
        am.openBrowser("http://haifa:5000");
        am.login("yoav", "yoav");
//        am.runSmMoleculeSearch(4, 70);
//        gr.compareResultsToJsonBaseLine(gr.getResultsAsMap("moleculeIdName", "moleculeResultName"), "molecule38Mil");
//        am.runSmVisualSearch(4, 15);
//        gr.compareResultsToJsonBaseLine(gr.getResultsAsMap("visualIdName", "visualResultName"), "visualParis");
        am.runFaceRecognition(29, 100);
        gr.createJsonBaseline("facesBaseline.json", "", "");
//        gr.compareResultsToJsonBaseLine(gr.getFacesResultsAsMap(), "facesBaseline");
//        am.quitDriver();
    }

}
