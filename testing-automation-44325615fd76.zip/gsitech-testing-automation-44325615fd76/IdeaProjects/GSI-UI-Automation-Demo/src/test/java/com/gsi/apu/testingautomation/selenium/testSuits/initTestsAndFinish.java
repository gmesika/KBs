package com.gsi.apu.testingautomation.selenium.testSuits;

import com.gsi.apu.testingautomation.selenium.atomic.atomicMethods;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;

public class initTestsAndFinish extends atomicMethods {

//    public void init(){
//
//        openBrowser("http://haifa:5000");
//        login("yoav", "yoav");
//        waitForElement("logo");
//        Assert.assertTrue(getWebElement("logo").isDisplayed());
//    }
//
//    public void finishTest() {
//        logout();
//       quitDriver();
//    }
}
