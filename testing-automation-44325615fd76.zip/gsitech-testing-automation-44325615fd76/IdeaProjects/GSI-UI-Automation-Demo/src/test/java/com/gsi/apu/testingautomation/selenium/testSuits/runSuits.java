package com.gsi.apu.testingautomation.selenium.testSuits;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import com.gsi.apu.testingautomation.selenium.atomic.atomicMethods;


@RunWith(Suite.class)
@Suite.SuiteClasses({
        moleculeSearchTest.class,
        visualSearchTest.class,
        faceRecTest.class
})
public class runSuits {


    public static atomicMethods am = new atomicMethods();

//    @BeforeClass
//    public static void start() {
//
//    }

    @Before
    public void init(){
    	String hostName = System.getProperty("HOST_NAME");
    	System.out.println("running on " + hostName + ":5000");
        am.openBrowser("http://" + hostName + ":5000");
        am.waitForElement("loginUsername");
        am.login("yoav", "yoav");
        am.waitForElement("logo");
        Assert.assertTrue(am.getWebElement("logo").isDisplayed());
    }


    @After
    public void logout(){
    	am.waitForElement("iconSettings");
        am.logout();
    }

//    @AfterClass
//    public static void finish() {
//        am.closeDriver();
//        am = new atomicMethods();
//        am.openBrowser("http://haifa:5000");
//    }
}
