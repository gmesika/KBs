package com.gsi.apu.testingautomation.selenium.atomic;

import com.gsi.apu.testingautomation.selenium.Infra.SeleniumWrappers;
import com.gsi.apu.testingautomation.selenium.Infra.httpResponseCode;
import com.gsi.apu.testingautomation.selenium.Infra.imageCompare;
import org.junit.Assert;
import org.openqa.selenium.*;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class atomicMethods extends SeleniumWrappers {

    private static httpResponseCode rc = new httpResponseCode();
    private static imageCompare ic = new imageCompare();

    private static double extractQueryResultAsDouble(String timerElement) {
        return Double.valueOf(getWebElement(timerElement).getAttribute("outerText").replace("Sec", "").trim());
    }

    private static File takeSnapshot() {
        File screenShot = ((TakesScreenshot)getDriver()).getScreenshotAs(OutputType.FILE);
        return screenShot;
    }

    public void openBrowser(String url){
        getDriver().get(url);
        getDriver().manage().window().maximize();
    }

    public void openNewTab(String url) {
        ((JavascriptExecutor)getDriver()).executeScript("window.open()");
        ArrayList<String> tabs = new ArrayList<String >(getDriver().getWindowHandles());
        getDriver().switchTo().window(tabs.get(1));
        getDriver().get(url);
    }

    public void login(String username, String password) {
        getElementAndSendKeys("loginUsername", username);
        getElementAndSendKeys("loginPassword", password);
        getElementAndClick("loginButton");
    }

    public void logout(){
        getElementAndClick("iconSettings");
        getElementAndClick("logoutButton");
    }
    public void backOfficeLogin(String username, String password) {
        login(username, password);
        waitForElement("iconSettings");
        getElementAndClick("iconSettings");
        getElementAndClick("backOffice");
        waitForElement("dataAndBoardsButton");
        getElementAndClick("iconSettings");
    }

    public void turnOnGnl() {
        waitForElement("iconSettings");
        getElementAndClick("iconSettings");
        getElementAndClick("gnlOnButton");
        waitForElement("gnlOnButton");
    }
    
    public float appearanceCheck(List<File> baselineList) {
        float testResult = 0;
        openNewTab("http://haifa:5000");
        List<File> testList = CollectImagesForComparison("yoav", "yoav");
        for (int i = 0; i < baselineList.size(); i++) {
            testResult = ic.compareImage(baselineList.get(i), testList.get(i));
            if(testResult < 95){
                break;
            }
        }
        return testResult;
    }

    public List<File> CollectImagesForComparison(String username, String password) {
        List<File> imagesList = new ArrayList<>();
        imagesList.add(takeSnapshot());
        login(username, password);
        waitForElement("logo");
        imagesList.add(takeSnapshot());
        getElementAndClick("visualButton");
        imagesList.add(takeSnapshot());
        getElementAndClick("faceRecButton");
        imagesList.add(takeSnapshot());
        getElementAndClick("faissButton");
        imagesList.add(takeSnapshot());
        logout();
        waitForElement("loginUsername");
        backOfficeLogin(username, password);
        getElementAndClick("adminButton");
        imagesList.add(takeSnapshot());
        getElementAndClick("utilitiesButton");
        imagesList.add(takeSnapshot());
        getElementAndClick("appsButton");
        imagesList.add(takeSnapshot());
        getElementAndClick("dataAndBoardsButton");
        imagesList.add(takeSnapshot());
        logout();
        return imagesList;
    }

    public double runSmMoleculeSearch(int selectionNumber, int topKNumber) {
        waitForElement("moleculeButton");
        turnOnGnl();
        checkIfElementShouldBeClicked("moleculeButton");
        getElementAndClick("loadButton");
        waitForElement("searchButton");
        getElementAndClick("selectButton");
        List<WebElement> images = getListOfElements("images");
        clickOnElements(images, selectionNumber);
        getElementAndClick("okButton");
        getElementAndSendKeys("topK", String.valueOf(topKNumber));
        waitForElement("topK");
        getElementAndClick("searchButton");
        waitForElement("queryTimer");
        return extractQueryResultAsDouble("queryTimer");
    }

    public double runSmVisualSearch(int selectionNumber, int topKNumber) {
        waitForElement("visualButton");
        turnOnGnl();
        checkIfElementShouldBeClicked("visualButton");
        waitForElement("loadButton");
        getElementAndClick("loadButton");
        waitForElement("searchButton");
        getElementAndClick("selectButton");
        List<WebElement> images = getListOfElements("images");
        clickOnElements(images, selectionNumber);
        getElementAndClick("okButton");
        getElementAndSendKeys("topK", String.valueOf(topKNumber));
        waitForElement("topK");
        getElementAndClick("searchButton");
        waitForElement("queryTimer");
        return extractQueryResultAsDouble("queryTimer");
    }

    public double runFaceRecognition(int selectionNumber, int topKNumber) {
        waitForElement("faceRecButton");
        turnOnGnl();
        checkIfElementShouldBeClicked("faceRecButton");
        waitForElement("loadButton");
        getElementAndClick("loadButton");
        waitForElement("searchButton");
        getElementAndClick("selectButton");
        List<WebElement> images = getListOfElements("images");
        clickOnElements(images, selectionNumber);
        getElementAndClick("okButton");
        getElementAndSendKeys("topK", String.valueOf(topKNumber));
        waitForElement("topK");
        getElementAndClick("searchButton");
        waitForElement("frTimer");
        return extractQueryResultAsDouble("frTimer");
    }

    public double runFaissBenchmark () {
        waitForElement("faissButton");
        checkIfElementShouldBeClicked("faissButton");
        // choose benchmark data
        List <WebElement> benchmark = getListOfElements("faissBenchmarkSelect");
        benchmark.get(2).click();
        Assert.assertTrue(getDriver().findElement(By.cssSelector("label > div > div > select")).getAttribute("value").equals("9"));
        String val = getDriver().findElement(By.cssSelector("label > div > div > select")).getAttribute("value");
        Assert.assertEquals("9", val);
//        waitForElement("searchButton");
//        getElementAndClick("searchButton");
        // compare results in PRF
        // compare results in TRD
        return 0.1;
    }

    public static void main(String[] args) {


        atomicMethods meth = new atomicMethods();
        meth.openBrowser("http://haifa:5000/");
        Assert.assertEquals("url received incorrect response code", httpResponseCode.httpResponseCodeViaGet("http://haifa:5000"), 200);
        List<File> baselineAppearance = meth.CollectImagesForComparison("yoav", "yoav");

        meth.login("yoav", "yoav");
        meth.waitForElement("logo");
        meth.turnOnGnl();
        Assert.assertTrue(meth.getWebElement("logo").isDisplayed());
        double result = meth.runSmMoleculeSearch(3, 5);
        double expected = 1.15;
        String errorMessage = "Time of SM molecule search not as expected: " + String.valueOf(expected) + " actual: " + String.valueOf(result);
        Assert.assertTrue(errorMessage, result <= expected);
        result = meth.runSmVisualSearch(4, 25);
        expected = 0.2;
        errorMessage = "Time of SM visual search not as expected: " + String.valueOf(expected) + " actual: " + String.valueOf(result);
        Assert.assertTrue(errorMessage, result <= expected);
        meth.logout();
        float appearanceTest = meth.appearanceCheck(baselineAppearance);
        System.out.println("Appearance test result is: " + appearanceTest);
        Assert.assertTrue("Appearance test failed:", appearanceTest >= 95);

//        meth.backOfficeLogin("yoav", "yoav");
////        meth.waitForElement("logo");
//
//
//        File screenshot1 = ((TakesScreenshot)getDriver()).getScreenshotAs(OutputType.FILE);
//        File screenshot2 = ((TakesScreenshot)getDriver()).getScreenshotAs(OutputType.FILE);
//        float ok = 100;
//        float actual = ic.compareImage(screenshot1, screenshot2);
//        System.out.println("actual = " + actual);
//        Assert.assertEquals(ok, actual, 0);
//        result = meth.runFaceRecognition(12, 25);
//        expected = 0.08;
//        errorMessage = "Time of face recognition not as expected: " + String.valueOf(expected) + " actual: " + String.valueOf(result);
//        Assert.assertTrue(errorMessage, result <= expected);
//        double result = meth.runFaissBenchmark();
        meth.quitDriver();
    }
}
