package com.gsi.apu.testingautomation.selenium.testSuits;


import io.qameta.allure.Description;
import io.qameta.allure.Severity;
import io.qameta.allure.SeverityLevel;
import io.qameta.allure.Story;

import org.hamcrest.CoreMatchers;
import org.hamcrest.core.Is;
import org.hamcrest.core.IsAnything;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import static org.junit.Assume.assumeThat;

import java.util.Arrays;
import java.util.Collection;

@RunWith(Parameterized.class)
public class faceRecTest extends runSuits {

    private int num;
    private int topK;

    @Parameterized.Parameters(name = "Number of Images Selected: {0}")
    public static Collection<Object[]> data() {
        return Arrays.asList(new Object[][] { {1}, {2}, {3}, {4}, {5}, {6}, {7}, {8}, {9}, {10}, {11}, {12}, {13}, {14}, {15}, {16}, {17}, {18}, {19}, {20}, {21}, {22}, {23}, {24}, {25}, {26} });
    }

    public faceRecTest(int numOfSelections) {
        this.num = numOfSelections;
        this.topK = numOfSelections + 16;
    }

    @Severity(SeverityLevel.CRITICAL)
    @Description("Test Face Recognition")
    @Story("Test Query time")
    @Test
    public void test() {
    	assumeThat(System.getProperty("RUN_FACE_REC"), CoreMatchers.is("True"));
        double threshold = 0.4;
        double result = this.am.runFaceRecognition(this.num, this.topK);
        String errorMsg = "Time exceeded threshold: " + threshold + " result: " + result;
        Assert.assertTrue(errorMsg, result < threshold );
        Assert.assertTrue("Query not completed: ", result >= 0 );
    }

}
