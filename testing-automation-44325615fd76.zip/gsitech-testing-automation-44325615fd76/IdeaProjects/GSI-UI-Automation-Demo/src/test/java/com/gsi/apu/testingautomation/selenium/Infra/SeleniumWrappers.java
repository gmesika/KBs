package com.gsi.apu.testingautomation.selenium.Infra;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

public class SeleniumWrappers {

    private static String pathToElementsJsonFile = new File("").getAbsolutePath() + "/src/test/resources/elementsJSON.json";
    private static ChromeOptions options = new ChromeOptions();
    private static JSONParser parser = new JSONParser();
    private static WebDriver driver;
    private static JSONArray elements;

    /**
     * constructor to retrieve the elements from the JSON file
     */
    public SeleniumWrappers() {
        try {
            //options.addArguments("start-maximized"); // open Browser in maximized mode
            //options.addArguments("disable-infobars"); // disabling infobars
            //options.addArguments("--disable-extensions"); // disabling extensions
            //options.addArguments("--disable-gpu"); // applicable to windows os only
            //options.addArguments("--disable-dev-shm-usage"); // overcome limited resource problems
            //options.addArguments("--no-sandbox"); // Bypass OS security model
            elements = (JSONArray) ((JSONObject) parser.parse(new FileReader(pathToElementsJsonFile))).get("elements");
            System.setProperty("webdriver.chrome.driver", "C:\\Users\\gsiit\\AppData\\Local\\Google\\Chrome\\Application\\chromedriver.exe");
            driver = new ChromeDriver(options);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    /**
     *
     * @return WebDriver for Selenium api
     */
    public static WebDriver getDriver() {

        return driver;
    }

    /**
     * quit method from Selenium
     */
    public void quitDriver() {
        driver.quit();
    }

    /**
     * close method from Selenium
     */
    public void closeDriver() {
        driver.close();
    }

    /**
     *
     * @param elementName The name of the Json object in file "elementsJSON.json"
     * @return WebElement to be used with Selenium api i.e. "click(), sendKeys()" etc.
     */
    public static WebElement getWebElement(String elementName) {
        return getDriver().findElement(getByType(elementName));
    }

    /**
     *
     * @param listName The name of the Json object in file elementsJSON.json which refers to a list of elements
     * @return List of WebElements to be used with Selenium api i.e. "click(), sendKeys()" etc.
     */
    public List<WebElement> getListOfElements(String listName) {
        return getDriver().findElements(getByType(listName));
    }

    /**
     *
     * @param clickableList List of WebElements to be clicked
     * @param numberOfClicks how many items from list to click, clicks will be performed by linear order
     */
    public void clickOnElements(List<WebElement> clickableList, int numberOfClicks) {
        for (int i = 0; i < numberOfClicks; i++) {
            new WebDriverWait(getDriver(), 2).until(ExpectedConditions.elementToBeClickable(clickableList.get(i)));
            clickableList.get(i).click();
        }
    }

    /**
     * @param elementName The name of the Json object in file "elementsJSON.json"
     */
    public void waitForElement(String elementName) {
        JSONObject elementObject = getJsonObject(elementName);
        JSONObject waitAttribute;
        String attribute;
        String condition = elementObject.get("condition").toString();
        Long timeout = (Long) elementObject.get("timeout");
        switch (condition){
            case ("isClickable"):
                new WebDriverWait(getDriver(), timeout).until(ExpectedConditions.elementToBeClickable(getByType(elementName)));
                break;
            case ("isDisplayed"):
                new WebDriverWait(getDriver(), timeout).until(displayed -> getWebElement(elementName).isDisplayed());
                break;
            case ("presenceOfElementLocated"):
                new WebDriverWait(getDriver(), timeout).until(ExpectedConditions.presenceOfElementLocated(getByType(elementName)));
                break;
            case ("visibilityOfElementLocated"):
                new WebDriverWait(getDriver(), timeout).until(ExpectedConditions.visibilityOfElementLocated(getByType(elementName)));
                break;
            case ("attributeContains"):
                waitAttribute = (JSONObject) elementObject.get("waitAttribute");
                attribute = waitAttribute.get("attribute").toString();
                String value = waitAttribute.get("value").toString();
                new WebDriverWait(getDriver(), timeout).until(ExpectedConditions.attributeContains(getWebElement(elementName), attribute, value));
                break;
            case ("attributeToBeNotEmpty"):
                waitAttribute = (JSONObject) elementObject.get("waitAttribute");
                attribute = waitAttribute.get("attribute").toString();
                new WebDriverWait(getDriver(), timeout).until(ExpectedConditions.attributeToBeNotEmpty(getWebElement(elementName), attribute));
                break;
            default:
                throw new IllegalStateException("Unexpected value: " + condition);
        }
    }

    /**
     *
     * @param elementName The name of the Json object in file "elementsJSON.json" to click
     */
    public void getElementAndClick(String elementName) {
        getWebElement(elementName).click();
    }

    /**
     * Use this method to simulate typing into an element, which may set its value.
     * @param elementName The name of the Json object in file "elementsJSON.json" to send input
     * @param input The input that will be sent to the WebElement
     */
    public void getElementAndSendKeys(String elementName, String input) {
        WebElement element = getWebElement(elementName);
        element.click();
        element.clear();
        element.sendKeys(input);
    }

    /**
     * checks if an element is not active and clicks it.
     * @param elementName The name of the Json object in file "elementsJSON.json"
     */
    public void checkIfElementShouldBeClicked(String elementName) {
        WebElement element = getWebElement(elementName);
        if (!element.getAttribute("class").equals("active")) {
            element.click();
        }
    }
    /**
     * @param objName The name of the Json object in file "elementsJSON.json"
     * @return A JSONObject which contains all fields relevant to retrieve WebElement or WebDriverWait
     */
    public static JSONObject getJsonObject(String objName) {
        String name = null;
        for (int i = 0; i < elements.size(); i++) {
            name = (((JSONObject) elements.get(i)).get("name")).toString();
            if (name.equals(objName)) {
                return (JSONObject) elements.get(i);
            }
        }
        throw new IllegalArgumentException(
                "element \"name\" not found in \"elementJSON.json\": " + name);
    }

    /**
     * @param elementName The name of the Json object in file "elementsJSON.json"
     * @return A By object to use if a locator is needed for getting WebElement or WebDriverWait
     */
    public static By getByType(String elementName) {
        JSONObject elementObject = getJsonObject(elementName);
        String type = elementObject.get("type").toString();
        String byAttribute = elementObject.get("byAttribute").toString();
        switch (type) {
            case ("id"):
                return (By.id(byAttribute));
            case ("className"):
                return (By.className(byAttribute));
            case ("cssSelector"):
                return (By.cssSelector(byAttribute));
            case ("linkText"):
                return (By.linkText(byAttribute));
            default:
                throw new IllegalStateException("Unexpected value: " + byAttribute);
        }
    }

    public static void main(String[] args) throws IOException {
        SeleniumWrappers sr = new SeleniumWrappers();
        driver.get("http://haifa:5000");
        driver.manage().window().maximize();
        WebElement elem = sr.getWebElement("loginUsername");
        elem.click();
        elem.sendKeys("yoav");
        elem = sr.getWebElement("loginPassword");
        elem.click();
        elem.sendKeys("yoav");
        sr.getWebElement("loginButton").click();
        sr.waitForElement("loadButton");
        sr.getWebElement("loadButton").click();
        sr.waitForElement("searchButton");
        driver.quit();
    }
}
