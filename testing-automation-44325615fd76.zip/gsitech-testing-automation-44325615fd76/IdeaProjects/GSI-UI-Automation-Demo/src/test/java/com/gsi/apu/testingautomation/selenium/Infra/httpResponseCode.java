package com.gsi.apu.testingautomation.selenium.Infra;

import io.restassured.RestAssured;

public class httpResponseCode {
    public static int httpResponseCodeViaGet(String url) {
        return RestAssured.get(url).statusCode();
    }

    public static int httpResponseCodeViaPost(String url) {
        return RestAssured.post(url).statusCode();
    }
}
