package com.gsi.apu.testingautomation.selenium.testSuits;


import io.qameta.allure.Description;
import io.qameta.allure.Severity;
import io.qameta.allure.SeverityLevel;
import io.qameta.allure.Story;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import java.util.Arrays;
import java.util.Collection;

@RunWith(Parameterized.class)
public class moleculeSearchTest extends runSuits {

    private int num;
    private int topK;

    @Parameterized.Parameters(name = "Number of Images Selected: {0}")
    public static Collection<Object[]> data() {
        return Arrays.asList(new Object[][] { {1}, {2}, {3}, {4}, {5}});
    }

    public moleculeSearchTest(int numOfSelections) {
        this.num = numOfSelections;
        this.topK = numOfSelections * numOfSelections;
    }

    @Severity(SeverityLevel.CRITICAL)
    @Description("Test Query SM Molecules")
    @Story("Test Query time")
    @Test
    public void test() {

        double threshold = 1.5;
        double result = this.am.runSmMoleculeSearch(this.num, this.topK);
        String errorMsg = "Time exceeded threshold: " + threshold + " result: " + result;
        Assert.assertTrue(errorMsg, result < threshold );
        Assert.assertTrue("Query not completed: ", result >= 0 );
    }

}
